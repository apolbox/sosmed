<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'apolboxc_wp750');

/** MySQL database username */
define('DB_USER', 'apolboxc_wp750');

/** MySQL database password */
define('DB_PASSWORD', 'np15S@(733');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '38bnazbrcymwl2bjzsdoekbmxqaldat9bjlrtkefge9dh2lwbibynkyroxqphjom');
define('SECURE_AUTH_KEY',  'u8v9we6dozekgtaqy6xkghvftu12xauhyxwfvkaco9zv50dbpfo7jt7twszqyzn5');
define('LOGGED_IN_KEY',    'jitgeevulqvcxwaumfiaktdwlhpv9wvjzo7yc9ylsbvbxtkryflzkilbp4d84fkl');
define('NONCE_KEY',        'pagabut7qsdivgt3dn8sepyuqrhlcf02kxygh0ofmrlxlc2jibwcnl54xc9fej3g');
define('AUTH_SALT',        'eirpqodcbakp3yj2hl67lriduotl1dktc7wjs44fnebqarvtchghs1hyufw1oo3h');
define('SECURE_AUTH_SALT', '6k9yhyzrschwvrli1vol89pxpetcxxfqdcnorlgpwmxbmu87wyxtgkmhsu9lj2rr');
define('LOGGED_IN_SALT',   'j11t5gpdc3x8q5c2s7ds4kuiqdtkfnkvhzibwx9az53vkrrq5ucr5pt9ctbicsun');
define('NONCE_SALT',       'x0lhgo9zxq1chpg2n9h6lmi0fx6roy5nel7s6mppljdcmwuzvs7puzlqvqaz5ftq');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpy6_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
